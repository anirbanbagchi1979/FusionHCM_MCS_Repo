angular.module('css.controllers')
  .factory('WOService', function($q, localstorage, UserAuthService, HostMcsUrl,
    MCSBackendID, $http) {
    return {
	  getExpenseReportById: function() {
        alert("In get Expense report ")
        var getUrl = HostMcsUrl + '/mobile/custom/getexpenses/expenses/100';
        var req = {
          method: 'GET',
          url: getUrl,
          /* we should look automate this process here as well */
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6InVzZXIyMTBfZHNpZyJ9.eyJvcmFjbGUub2F1dGgudGtfY29udGV4dCI6InVzZXJfYXNzZXJ0aW9uIiwiZXhwIjoxNDM3NjE3NzU3MDAwLCJzdWIiOiJUZWFtQ2FtZWxfMTEiLCJpc3MiOiJ3d3cub3JhY2xlLmNvbSIsInBybiI6IlRlYW1DYW1lbF8xMSIsImp0aSI6IjBjNDBiNWQyLTVkZDAtNDk3ZC1hN2JhLWRjNWRkYzMxYzdjOSIsIm9yYWNsZS5vYXV0aC5jbGllbnRfb3JpZ2luX2lkIjoiRW1wbG95ZWVFeHBlbnNlc19BQi8xLjAvYzczNDljMzQxZDhkYzcxYjhlMTYyZjdlMTdiMTVjMzkiLCJvcmFjbGUub2F1dGguc3ZjX3BfbiI6Ik9BdXRoU2VydmljZVByb2ZpbGUiLCJpYXQiOjE0Mzc1ODg5NTcwMDAsIm9yYWNsZS5vYXV0aC5pZF9kX2lkIjoiMTIzNDU2NzgtMTIzNC0xMjM0LTEyMzQtMTIzNDU2Nzg5MDEyIiwidXNlci50ZW5hbnQubmFtZSI6IkRlZmF1bHREb21haW4iLCJvcmFjbGUub2F1dGgucHJuLmlkX3R5cGUiOiJMREFQX1VJRCJ9.R2HP9xE53er1g4-WSR1tn8RED0nhfGTa5Rrxx9U6EDCkxy-8j8KGbqfI6KAGpE5lTtr2yfwVsWdMDJv-uz9NwuOT9wOVzcMfs7v_3xWWqIZe80zntzlDQsXtxDSspMGVPCitJUqaTI09j9GBjPDojOViFRQgXEEgYhfy9lZ7ee4'
          }
          // data: 'grant_type=password&username=' + username + '&password=' + password
          //data: 'grant_type=password&username=lynn&password=123456'
        };
        
		var resp = $http(req);
		//alert("Anirban" + resp.data);
        return resp ;
      },

      getWorkOrders: function() {
		  alert("In get WO")
        var getUrl = HostMcsUrl + '/mobile/custom/getemployeesHCM/employees';
        var req = {
          method: 'GET',
          url: getUrl,
          /* we should look automate this process here as well */
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6InVzZXIyMTBfZHNpZyJ9.eyJvcmFjbGUub2F1dGgudGtfY29udGV4dCI6InVzZXJfYXNzZXJ0aW9uIiwiZXhwIjoxNDM3NjA1NDAxMDAwLCJzdWIiOiJUZWFtQ2FtZWxfMTEiLCJpc3MiOiJ3d3cub3JhY2xlLmNvbSIsInBybiI6IlRlYW1DYW1lbF8xMSIsImp0aSI6ImU5MDMzMDlhLTIwODYtNDE1ZS05MWE4LTU0MjA2ZTNhYmQ1MCIsIm9yYWNsZS5vYXV0aC5jbGllbnRfb3JpZ2luX2lkIjoiRW1wbG95ZWVFeHBlbnNlc19BQi8xLjAvYzczNDljMzQxZDhkYzcxYjhlMTYyZjdlMTdiMTVjMzkiLCJvcmFjbGUub2F1dGguc3ZjX3BfbiI6Ik9BdXRoU2VydmljZVByb2ZpbGUiLCJpYXQiOjE0Mzc1NzY2MDEwMDAsIm9yYWNsZS5vYXV0aC5pZF9kX2lkIjoiMTIzNDU2NzgtMTIzNC0xMjM0LTEyMzQtMTIzNDU2Nzg5MDEyIiwidXNlci50ZW5hbnQubmFtZSI6IkRlZmF1bHREb21haW4iLCJvcmFjbGUub2F1dGgucHJuLmlkX3R5cGUiOiJMREFQX1VJRCJ9.f-wxelU0B260I7tG_OXpB1cTaRMQHIGIIbE8Z720l0humZlD5u6K54vWoYryLK9jviKFRYtbuvltNRZyK4SKzY0eFbLDkOzDQu9jvqFkzL9DE_Muoa5kw2n2kEJIgHS6OOZ0FhrqX5GGYi6z4r-KBK3p0dsL_PVoEK3xiVzc99E'

          }
          // data: 'grant_type=password&username=' + username + '&password=' + password
          //data: 'grant_type=password&username=lynn&password=123456'
        };
        //console.log("Anirban" + req);
		var resp = $http(req);
		//console.log("Anirban" + resp);
        return resp ;
      },

      getWorkOrdersFiltered: function() {
        if (UserAuthService.isTechnician()) {
          var getUrl = HostMcsUrl + '/mobile/custom/getemployeesHCM/employees';

        } else if (UserAuthService.isServiceWriter()) {
          var getUrl = HostMcsUrl + '/mobile/custom/getemployeesHCM/employees';
        }

        var req = {
          method: 'GET',
          url: getUrl,
          /* we should look automate this process here as well */
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6InVzZXIyMTBfZHNpZyJ9.eyJvcmFjbGUub2F1dGgudGtfY29udGV4dCI6InVzZXJfYXNzZXJ0aW9uIiwiZXhwIjoxNDM3NjA1NDAxMDAwLCJzdWIiOiJUZWFtQ2FtZWxfMTEiLCJpc3MiOiJ3d3cub3JhY2xlLmNvbSIsInBybiI6IlRlYW1DYW1lbF8xMSIsImp0aSI6ImU5MDMzMDlhLTIwODYtNDE1ZS05MWE4LTU0MjA2ZTNhYmQ1MCIsIm9yYWNsZS5vYXV0aC5jbGllbnRfb3JpZ2luX2lkIjoiRW1wbG95ZWVFeHBlbnNlc19BQi8xLjAvYzczNDljMzQxZDhkYzcxYjhlMTYyZjdlMTdiMTVjMzkiLCJvcmFjbGUub2F1dGguc3ZjX3BfbiI6Ik9BdXRoU2VydmljZVByb2ZpbGUiLCJpYXQiOjE0Mzc1NzY2MDEwMDAsIm9yYWNsZS5vYXV0aC5pZF9kX2lkIjoiMTIzNDU2NzgtMTIzNC0xMjM0LTEyMzQtMTIzNDU2Nzg5MDEyIiwidXNlci50ZW5hbnQubmFtZSI6IkRlZmF1bHREb21haW4iLCJvcmFjbGUub2F1dGgucHJuLmlkX3R5cGUiOiJMREFQX1VJRCJ9.f-wxelU0B260I7tG_OXpB1cTaRMQHIGIIbE8Z720l0humZlD5u6K54vWoYryLK9jviKFRYtbuvltNRZyK4SKzY0eFbLDkOzDQu9jvqFkzL9DE_Muoa5kw2n2kEJIgHS6OOZ0FhrqX5GGYi6z4r-KBK3p0dsL_PVoEK3xiVzc99E'

          }
          // data: 'grant_type=password&username=' + username + '&password=' + password
          //data: 'grant_type=password&username=lynn&password=123456'
        };
        console.log(req);
        return $http(req);

      },

      getWorkOrderById: function(workOrderID) {
		  alert("PersonID" + workOrderID)
        var getUrl = '';
        if (UserAuthService.isTechnician()) {
          getUrl = HostMcsUrl + '/mobile/custom/getemployeesHCM/employees/search/' +
            workOrderID;

        } else if (UserAuthService.isServiceWriter()) {
          getUrl = HostMcsUrl + '/mobile/custom/getemployeesHCM/employees/search/' +
            workOrderID;
        }
        var req = {
          method: 'GET',
          url: getUrl,
          /* we should look automate this process here as well */
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6InVzZXIyMTBfZHNpZyJ9.eyJvcmFjbGUub2F1dGgudGtfY29udGV4dCI6InVzZXJfYXNzZXJ0aW9uIiwiZXhwIjoxNDM3NjA1NDAxMDAwLCJzdWIiOiJUZWFtQ2FtZWxfMTEiLCJpc3MiOiJ3d3cub3JhY2xlLmNvbSIsInBybiI6IlRlYW1DYW1lbF8xMSIsImp0aSI6ImU5MDMzMDlhLTIwODYtNDE1ZS05MWE4LTU0MjA2ZTNhYmQ1MCIsIm9yYWNsZS5vYXV0aC5jbGllbnRfb3JpZ2luX2lkIjoiRW1wbG95ZWVFeHBlbnNlc19BQi8xLjAvYzczNDljMzQxZDhkYzcxYjhlMTYyZjdlMTdiMTVjMzkiLCJvcmFjbGUub2F1dGguc3ZjX3BfbiI6Ik9BdXRoU2VydmljZVByb2ZpbGUiLCJpYXQiOjE0Mzc1NzY2MDEwMDAsIm9yYWNsZS5vYXV0aC5pZF9kX2lkIjoiMTIzNDU2NzgtMTIzNC0xMjM0LTEyMzQtMTIzNDU2Nzg5MDEyIiwidXNlci50ZW5hbnQubmFtZSI6IkRlZmF1bHREb21haW4iLCJvcmFjbGUub2F1dGgucHJuLmlkX3R5cGUiOiJMREFQX1VJRCJ9.f-wxelU0B260I7tG_OXpB1cTaRMQHIGIIbE8Z720l0humZlD5u6K54vWoYryLK9jviKFRYtbuvltNRZyK4SKzY0eFbLDkOzDQu9jvqFkzL9DE_Muoa5kw2n2kEJIgHS6OOZ0FhrqX5GGYi6z4r-KBK3p0dsL_PVoEK3xiVzc99E'

          }
          // data: 'grant_type=password&username=' + username + '&password=' + password
          //data: 'grant_type=password&username=lynn&password=123456'
        };
		//console.log("Anirban" + req);
		var resp = $http(req);
        return resp;

      },

      createWorkOrder: function(workOrder) {
        console.log(workOrder);
        var postUrl = HostMcsUrl + '/mobile/custom/css/workOrders';
        workOrder.sendEmail = '1';
        workOrder.to = 'anirban.bagchi@oracle.com';
        var req = {
          method: 'POST',
          url: postUrl,
          data: workOrder,
          /* we should look automate this process here as well */
          headers: {
            'Content-Type': 'application/json',
            'Oracle-Mobile-Backend-Id': MCSBackendID
          }
          // data: 'grant_type=password&username=' + username + '&password=' + password
          //data: 'grant_type=password&username=lynn&password=123456'
        };
        console.log(req);
        return $http(req);
      },

      updateDSID: function(workOrderID) {
        console.log(workOrderID);
        var postUrl = HostMcsUrl + '/mobile/custom/css/workOrders/' + workOrderID;
        var patchData = [{
          op: 'add',
          path: '/workOrders/dsid'
        }];
        var req = {
          method: 'PATCH',
          url: postUrl,
          data: patchData,
          /* we should look automate this process here as well */
          headers: {
            'Content-Type': 'application/json',
            'Oracle-Mobile-Backend-Id': MCSBackendID
          }
          // data: 'grant_type=password&username=' + username + '&password=' + password
          //data: 'grant_type=password&username=lynn&password=123456'
        };
        console.log(req);
        return $http(req);
      },

      prepareForQuote: function(workOrderID) {
        console.log(workOrderID);
        var postUrl = HostMcsUrl + '/mobile/custom/css/workOrders/' + workOrderID;
        var patchData = [{
          op: 'add',
          path: '/workOrders/quote',
          sendEmail:'1',
          to: 'anirban.bagchi@oracle.com'
        }];
        var req = {
          method: 'PATCH',
          url: postUrl,
          data: patchData,
          /* we should look automate this process here as well */
          headers: {
            'Content-Type': 'application/json',
            'Oracle-Mobile-Backend-Id': MCSBackendID
          }
          // data: 'grant_type=password&username=' + username + '&password=' + password
          //data: 'grant_type=password&username=lynn&password=123456'
        };
        console.log(req);
        return $http(req);
      },
      getCSV: function() {
        var getUrl = HostMcsUrl + '/mobile/custom/css/workOrders';
        var req = {
          method: 'GET',
          url: getUrl,
          /* we should look automate this process here as well */
          headers: {
            'Accept':'text/csv',
            'Content-Type': 'application/json',
            'Oracle-Mobile-Backend-Id': MCSBackendID

          }
          // data: 'grant_type=password&username=' + username + '&password=' + password
          //data: 'grant_type=password&username=lynn&password=123456'
        };
        console.log(req);
        return $http(req);
      }



    };
  });
